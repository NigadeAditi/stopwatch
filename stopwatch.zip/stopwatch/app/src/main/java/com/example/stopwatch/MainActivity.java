package com.example.stopwatch;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView timeDisplay;
    private Button startButton, stopButton, holdButton;

    private Handler handler = new Handler();
    private long startTime = 0L, timeInMillis = 0L, updatedTime = 0L, holdTime = 0L;
    private boolean isRunning = false;

    private Runnable updateTimeRunnable = new Runnable() {
        @Override
        public void run() {
            timeInMillis = System.currentTimeMillis() - startTime;
            updatedTime = holdTime + timeInMillis;

            int secs = (int) (updatedTime / 1000);
            int mins = secs / 60;
            int hrs = mins / 60;
            secs = secs % 60;
            mins = mins % 60;

            timeDisplay.setText(String.format("%02d:%02d:%02d", hrs, mins, secs));
            handler.postDelayed(this, 1000); // Updates every second
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timeDisplay = findViewById(R.id.timeDisplay);
        startButton = findViewById(R.id.startButton);
        stopButton = findViewById(R.id.stopButton);
        holdButton = findViewById(R.id.holdButton);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isRunning) {
                    startTime = System.currentTimeMillis();
                    handler.postDelayed(updateTimeRunnable, 0);
                    isRunning = true;
                }
            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isRunning) {
                    handler.removeCallbacks(updateTimeRunnable);
                    isRunning = false;
                    timeDisplay.setText("00:00:00");
                    holdTime = 0L;
                }
            }
        });

        holdButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isRunning) {
                    holdTime += timeInMillis;
                    handler.removeCallbacks(updateTimeRunnable);
                    isRunning = false;
                } else {
                    startTime = System.currentTimeMillis();
                    handler.postDelayed(updateTimeRunnable, 0);
                    isRunning = true;
                }
            }
        });
    }
}
